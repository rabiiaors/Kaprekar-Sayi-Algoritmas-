#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
	int a,b,c,d,sayi,k1,k2,y1,y2,o1,o2,ek,ey,o3,o4,ksayi,bsayi,sayac=1;
	printf("4 basamakli sayi girin: ");
	scanf("%d",&sayi);
	if (sayi<1000 | sayi>9999)
	printf("sayi 4 basamakli degil");
	else
	{
	do {
	a=sayi/1000;
	b=(sayi%1000)/100;
	c=(sayi%100)/10;
	d=sayi%10;
	if (a < b) {
        k1 = a;
        y1 = b;}
    else {
        k1 = b;
        y1 = a;}

    if (c < d) {
        k2 = c;
        y2 = d;}
    else {
        k2 = d;
        y2 = c;}

    if (k1 < k2) {
        ek = k1;
        o1 = k2;}
    else {
        ek = k2;
        o1 = k1;}

    if (y1 > y2) {
        ey = y1;
        o2 = y2;}
    else {
        ey = y2;
        o2 = y1;}

    if (o1 < o2) {
        o3=o1;
        o4=o2;}
    else {
        o3=o2;
        o4=o1;}
    bsayi= ey*1000+o4*100+o3*10+ek;
    ksayi= ek*1000+o3*100+o4*10+ey;
    sayi=bsayi-ksayi;
    printf("Adim %d: %d - %d = %d\n",sayac,bsayi,ksayi,sayi);
    if (sayi==6174)
    {
		printf("Sayi kaprekar");
    	sayac=10;
	}
    sayac++;
} while (sayac<=7);
	if (sayac=8 && sayi!=6174)
	printf("Sayi kaprekar degil");
    }
	return 0;
}
